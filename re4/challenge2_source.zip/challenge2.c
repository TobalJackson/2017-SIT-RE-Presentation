#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char key[] = "scribblederth";

char flag[28] = {32, 42, 38, 18, 12, 82, 24, 58, 81, 10, 45, 28, 92, 1, 7, 45, 7, 82, 21, 51, 50, 80, 22, 45, 29, 95, 14};

int validate(char* input){
	if (strlen(input) == 16){
		return 1;
	}
	else
		return 0;
}

void decryptFlag(){
	int keylen = (strlen(key));
	int i;
	for (i=0; i<27; i++){
		flag[i] = flag[i] ^ key[i%keylen];
	}
}

int main(int argc, char* argv[]){
	if (argc < 2){
		printf("Usage: ./challenge2 <input>\n");
		exit(0);
	}
	else if (validate(argv[1])){
		decryptFlag();
		printf("You win! Flag: %s\n", flag);
		exit(0);
	}
	else{
		printf("Incorrect input!\n");
		exit(0);
	}

}
